
const express=require('express');
const app=express();
app.use(express.static('client'));
app.get('/api/health',(req,res)=>res.json({ok:true,name:'iwotandtalk'}));
app.listen(process.env.PORT||3000,()=>console.log('running'));
