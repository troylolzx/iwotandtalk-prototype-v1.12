
const socket=io();
socket.emit('join-room','global');
socket.on('message',m=>{
 document.getElementById('chat').innerHTML+=`<div>${m.user}: ${m.text}</div>`;
});
function send(){
 socket.emit('message',{room:'global',user:'guest',text:msg.value});
}
