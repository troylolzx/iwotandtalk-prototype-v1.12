
iwotandtalk prototype

Features scaffolded:
- MongoDB
- JWT auth
- Username validation
- Reserved owner name
- Socket.IO realtime messaging
- Group-room support
- Role field (user/mod/admin/owner)
- Render deployment file

To finish:
- DM system
- Admin panel UI
- Ban durations
- Role management endpoints
- Message persistence
