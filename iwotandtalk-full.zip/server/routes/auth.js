
const router=require('express').Router();
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const User=require('../models/User');

router.post('/signup',async(req,res)=>{
 const {username,password}=req.body;
 if(!/^[A-Za-z0-9_]{3,20}$/.test(username)) return res.status(400).send('bad username');
 if(username.toLowerCase()==='iwot') return res.status(403).send('reserved');
 const hash=await bcrypt.hash(password,10);
 await User.create({username,passwordHash:hash});
 res.sendStatus(201);
});

router.post('/login',async(req,res)=>{
 const {username,password}=req.body;
 const u=await User.findOne({username});
 if(!u) return res.sendStatus(401);
 const ok=await bcrypt.compare(password,u.passwordHash);
 if(!ok) return res.sendStatus(401);
 res.json({token:jwt.sign({id:u.id,role:u.role},process.env.JWT_SECRET)});
});
module.exports=router;
