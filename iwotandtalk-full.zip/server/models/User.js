
const mongoose=require('mongoose');
module.exports=mongoose.model('User',new mongoose.Schema({
 username:{type:String,unique:true},
 passwordHash:String,
 role:{type:String,default:'user'},
 banned:{type:Boolean,default:false}
}));
