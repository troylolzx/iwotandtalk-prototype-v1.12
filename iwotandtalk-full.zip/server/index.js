
require('dotenv').config();
const express=require('express');
const mongoose=require('mongoose');
const http=require('http');
const {Server}=require('socket.io');
const app=express();
app.use(express.json());
app.use(express.static('client'));
app.use('/api/auth',require('./routes/auth'));
mongoose.connect(process.env.MONGO_URI);
const server=http.createServer(app);
const io=new Server(server,{cors:{origin:'*'}});
io.on('connection',s=>{
 s.on('join-room',r=>s.join(r));
 s.on('message',m=>io.to(m.room).emit('message',m));
});
server.listen(process.env.PORT||3000);
